-- Cameron Nichols
-- Vincent Nguyen
-- Claire Hardgrove


create domain email_t as varchar(100) check (lower(member) like '%@%%.%');

-- enumerated location types defined by market.
create type area_t as enum ('inner west', 'lower north shore', 'hills district');
create type state_t as enum ('vic','nsw','tas','act','nt','wa','sa','qld'); -- pull in list
create type country_t as enum ('au', 'nz'); -- pull in list of all countries /customers in market

create table location (
	id bigserial,
	location_type varchar(10) check (location_type in ('customer', 'fleet')),
	detail varchar(100), 				-- TODO: required for customer address
	street varchar(50) not null,		-- required for both location types
	suburb varchar(50) not null,		-- required for both location types
	area area_t, 						-- only required for car_bay / home_bay
	state state_t not null, 			-- as market expands beyond one state migrate to postgis
	country country_t not null,			-- and loosen constraints on customer address fields.
	constraint location_pk primary key (id)
);

create table car_bay (
	name varchar(50),
	address bigint, --TODO: add constraint that location must have an area.
	description varchar(100) not null,
	latitude numeric(9,3) not null, -- please can we postgis. espg3875
	longtitude numeric(10,3) not null, -- please can we postgis.
	constraint car_bay_pk primary key (name), -- pk enforces uniqueness anyway.
	constraint car_bay_fk foreign key (address) references location (id) on delete set null on update cascade
);

--create type transmission_t as enum ('manual', 'automatic');
create table car_make_model (
	make varchar(20),
	model varchar(20),
	category varchar(20) not null,
	capacity integer not null,
	unique (make, model),
	constraint car_make_model_pk primary key (make, model)

);

create table car (
	regno integer,
	name varchar(50) not null, -- made unique for constraints
	year integer not null check((year > 1850) and (year <= date_part('year', current_date))),
	model varchar(20) not null,
	make varchar(20) not null,
	transmission varchar(10) not null check(lower(transmission) in ('manual', 'automatic')),
	constraint car_pk primary key (regno),
	constraint car_fk foreign key (make, model) references car_make_model(make, model) on delete no action on update no action
);

-- removed subscription table, pk of the member should be enough.

create table membership_plan  ( -- renamed to membership_plan
	title varchar(20),
	monthly_fee integer,
	hourly_rate integer,
	km_rate integer,
	daily_rate integer,
	daily_km_rate integer,
	daily_km_included integer,
	constraint membership_plan_pk primary key (title)
);

create table license ( -- new table
	license_no varchar(20), -- jurisdiction dependent format may include alphas.
	validated boolean,
	expiry date check (expiry > current_date),
	constraint license_pk primary key (license_no)
	-- trigger log update if license expires
);

create table member (
	member email_t,
	hash varchar(100) not null,
	family_name varchar(100) not null,
	given_name varchar(100) not null,
	nickname varchar(100),
	title varchar(10) check(lower(title) in (null, 'mr', 'mrs', 'dr', 'miss', 'ms', 'sir', 'lady', 'lord')),
	address bigint,
	home_bay varchar(50), -- optional
	license varchar(20) not null,
	birthdate date not null,
	join_date date not null,
	subscription varchar(20) not null, -- must they be subscribed?
	preferred_phone integer not null,
	preferred_payment integer not null,
	constraint member_pk primary key (member),
	constraint member_subscription_fk foreign key (subscription) references membership_plan (title) on delete no action on update no action,
	constraint member_home_bay_fk foreign key (home_bay) references car_bay (name) on delete set null on update cascade,
	constraint member_address_fk foreign key (address) references location (id) on delete set null on update cascade,
	constraint member_license_fk foreign key (license) references license (license_no) on delete set null on update cascade
	--TODO: trigger log all changes to license  number for liability reasons.
);

create table phone (
	member email_t,
	phone_number integer,
	phone_type varchar(20),
	constraint phone_pk primary key (member, phone_number),
	constraint phone_fk foreign key (member) references member (member) on update cascade
);

create table payments (
	num integer check (num between 1 and 3),
	member email_t,
	method_type varchar(50) not null CHECK(lower(method_type) in ('bank account', 'paypal', 'credit card')),
	constraint payments_pk primary key (member, num),
	constraint payments_fk foreign key (member) references member (member) on update cascade
);

create table bank_account (
	num integer,
	member email_t, -- added
	name varchar(100) not null,
	bsb integer not null check (bsb between 100000 and 999999), -- add domain
	account varchar(50) not null,
	constraint bank_account_pk primary key (member, num),
	constraint bank_account_fk foreign key (member, num) references payments (member, num) on update cascade
);

create table paypal (
	num integer,
	member email_t,
	constraint paypal_pk primary key (member, num),
	constraint paypay_fk foreign key (member, num) references payments (member, num) on update cascade
);

create table credit_card (
	num integer,
	member email_t, -- added
	name varchar(100) not null,
	brand varchar(50) not null,
	expires date not null CHECK(expires > CURRENT_DATE), -- make a trigger if this no longer true
	card_number integer not null,
	constraint credit_card_pk primary key (num, member),
	constraint credit_card_fk foreign key (num, member) references payments (num, member) on update cascade
);

-- add constraints to
alter table member add constraint member_preferred_phone_fk foreign key (member, preferred_phone) references phone(member, phone_number);
alter table member add constraint member_preferred_payment_fk foreign key (member, preferred_payment) references payments(member, num);

create table passhash (
	member email_t not null,
	salt varchar(20) not null,
	constraint passhash_pk primary key (member),
	constraint passhash_fk foreign key (member) references member (member)
);

create table bookings (
	booking_id bigserial,
	member email_t not null,
	when_booked timestamp with time zone not null default current_timestamp,
	duration interval not null default 'P0T1',
	start_time timestamp,
	car integer not null,
	constraint bookings_pk primary key (booking_id),
	constraint bookings_member_fk foreign key (member) references member (member) on update cascade,
	constraint bookings_car_fk foreign key (car) references car (regno) on update cascade on delete cascade
);


-- function and trigger check whether a car is already booked before inserting a new booking
create or replace function check_car_booked() returns trigger as $booked$
begin
	if
		exists(
		select b.car from bookings b
		where (b.car = NEW.car and
		b.start_time + b.duration > NEW.start_time))
	then
		insert into bookings
		values(NEW.booking_id, NEW.member, NEW.when_booked, NEW.duration, NEW.start_time, NEW.car);
	else
		raise exception 'car already booked';
	end if;
return NEW;
end $booked$ LANGUAGE plpgsql;

create trigger check_car_booked
before insert or update on bookings
for each row execute procedure check_car_booked();

-- maintain a record of changes to license details for legal requirements.
create table licenselog(
	old_license varchar(20) not null,
	new_license varchar(20) not null,
	date_modified timestamp with time zone not null
);

create or replace function license_logger() returns trigger as $licensed$
begin
	insert into licenselog
	values(OLD.license_no, NEW.license_no, current_timestamp);
return new;
end $licensed$ LANGUAGE plpgsql;

create trigger license_logging
after update of license_no on license
for each row execute procedure license_logger();

-- assertion to check that a person making a booking will be licensed up to the time the booking ends.
-- create assertion license_check
-- check(exists
--     (select email from (member join license using (license_no))
--     join bookings using (email)
--	   where validated is true and expiry < (start_time + duration))
--     )


--Checklist
--[x] ON DELETE clauses
--[x] UNIQUE clauses
--[x] DEFAULT clauses
--[x] Unique nicknames (spec says unique... this is enforced anyway by pk but added for clarity)
--[x] advanced domain constraint (emails)
--[x] non trivial trigger supporting a constraint (check_car_booked)
--[x] substitution of mutable natural keys with surrogate sequences (bigserial location -> bigint addresses)
--[x] assertion (license_check)
