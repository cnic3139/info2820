﻿CREATE MATERIALIZED VIEW matview_all_bays AS
name varchar primary key references carbay
	on update cascade
	on delete cascade,
address varchar foreign key references carbay
	on update cascade
	on delete cascade
;

CREATE INDEX ON matview_all_bays(address); -- for $#!75 and giggles

CREATE FUNCTION matview_carbay_insert() RETURNS TRIGGER
AS $$
BEGIN
	IF NOT EXISTS (
		SELECT name, address
		FROM matview_all_bays
		WHERE name	=New.name 
		AND address	=NEW.address)
	THEN
		INSERT INTO matview_all_bays (name, address)
		VALUES (NEW.name, NEW.address);
	END IF;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER matview_carbay_insert
AFTER INSERT ON carbay
FOR EACH ROW EXECUTE PROCEDURE matview_carbay_insert()



-- ON DELETE CASCADE ON UPDATE CASCADE of location are handled by carbay CONSTRAINTS
-- TODO: ON DELETE CASCADE ON UPDATE CASCADE OF carbay.
-- TODO: Make get_all_bays() SELECT from matview_all_bays
-- TODO: Create multilevel search on state, area, suburb
