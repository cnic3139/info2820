﻿--Function: carsharing.checklogin(character varying, character varying)

-- DROP FUNCTION carsharing.check_login(character varying, character varying);
ALTER TABLE member ALTER COLUMN password TYPE varchar(256);
ALTER TABLE member ALTER COLUMN pw_salt TYPE varchar(32);
ALTER TABLE member ADD COLUMN hashed BOOLEAN DEFAULT FALSE;

-- helper for preprocess.py adds a salt to a member
CREATE OR REPLACE FUNCTION carsharing.set_salt(pyemail TEXT, digest TEXT)
RETURNS BOOLEAN
AS $$
BEGIN
	UPDATE member SET pw_salt=digest
	WHERE email = pyemail;
	RETURN TRUE;
END;
$$ LANGUAGE plpgsql;

-- helper for preprocess.py hashes one password
CREATE OR REPLACE FUNCTION carsharing.hash_password(pyemail TEXT, salted_password TEXT)
RETURNS BOOLEAN
AS $$
BEGIN
	UPDATE member SET password=salted_password
	WHERE email = pyemail;
	--NEW.password := digest(NEW.password, 'sha256');
	RETURN TRUE;
END;
$$ LANGUAGE plpgsql;

-- CREATE EXTENSION pgcrypto;
--Triggers that we would implement if pgcrypto available
--Requires update to hash_password() and check_set_salt()
--CREATE TRIGGER trigger_hash_password
--ON INSERT OR UPDATE OF member
--FOR EACH ROW EXECUTE PROCEDURE hash_password()

--CREATE TRIGGER trigger_hash_salt
--ON INSERT OF member
--FOR EACH ROW EXECUTE PROCEDURE set_salt()

-- Function: carsharing.get_member_salt(character varying, character varying)

-- DROP FUNCTION carsharing.get_member_salt(character varying, character varying);

CREATE OR REPLACE FUNCTION carsharing.get_salt(
    IN inputemail character varying)
  RETURNS TABLE(member_pw_salt text) AS
$BODY$

BEGIN
	RETURN QUERY
	SELECT pw_salt::text
	FROM Member
	WHERE email = inputemail;
END
$BODY$
  LANGUAGE plpgsql; 


-- Function: carsharing.check_login(character varying, character varying)

-- DROP FUNCTION carsharing.check_login(character varying, character varying);

CREATE OR REPLACE FUNCTION carsharing.check_login(
    IN inputemail character varying,
    IN input_hash character varying)
  RETURNS TABLE(nickname character varying, nametitle character varying, namegiven character varying, namefamily character varying, address character varying, name character varying, since date, subscribed character varying, stat_nrofbookings integer) AS
$BODY$

BEGIN
	RETURN QUERY
	SELECT M.nickname, M.nametitle, M.namegiven, M.namefamily, M.address, C.name, M.since, M.subscribed, M.stat_nrOfBookings
		FROM CarSharing.Member M
		JOIN CarSharing.carbay C ON (homebay = bayid)
		WHERE EXISTS(SELECT 1 FROM CarSharing.Member M2 WHERE M2.email = inputemail AND M2.password = input_hash)
		AND (M.email = inputemail);
END
$BODY$
  LANGUAGE plpgsql; 


  -- Function: carsharing.check_password(text, text)

  -- DROP FUNCTION carsharing.check_password(text, text);

  CREATE OR REPLACE FUNCTION carsharing.check_password(
      email text,
      pass_hash text)
    RETURNS boolean AS
  $BODY$
  DECLARE passed BOOLEAN;
  BEGIN
  	SELECT (pass_hash = $2) INTO passed
  	FROM member
  	WHERE email = $1;
  END
  $BODY$
    LANGUAGE plpgsql; 

    -- Function: carsharing.get_all_bays()

    -- DROP FUNCTION carsharing.get_all_bays();

    CREATE OR REPLACE FUNCTION carsharing.get_all_bays()
      RETURNS TABLE(bay_name character varying, address character varying) AS
    $BODY$

    BEGIN
    	RETURN QUERY
    		SELECT DISTINCT CB.name, CB.address
    		FROM Car C JOIN CarBay CB ON (bayID = parkedAt);
    END
    $BODY$
     LANGUAGE plpgsql;

      -- Function: carsharing.get_all_bays_and_count()

      -- DROP FUNCTION carsharing.get_all_bays_and_count();

      CREATE OR REPLACE FUNCTION carsharing.get_all_bays_and_count()
        RETURNS TABLE(bay_name character varying, bay_address character varying, count bigint) AS
      $BODY$

      BEGIN
      	RETURN QUERY
      		SELECT CB.name, CB.address, count(parkedAt)
      		FROM Car C JOIN CarBay CB ON (bayID = parkedAt)
      		GROUP BY CB.name, CB.address
      		ORDER BY CB.name, CB.address;

      END
      $BODY$
        LANGUAGE plpgsql; 

        -- Function: carsharing.get_all_booking(character varying)

        -- DROP FUNCTION carsharing.get_all_booking(character varying);

        CREATE OR REPLACE FUNCTION carsharing.get_all_booking(IN email_input character varying)
          RETURNS TABLE(car_regno regotype, car_name character varying, date_time date, duration integer) AS
        $BODY$
        	DECLARE
        	member_no_input INTEGER;

        	BEGIN
        	member_no_input = (SELECT memberno FROM Member WHERE email = email_input);
        	RETURN QUERY
        		SELECT C.regno, C.name, B.starttime ::date as date, floor((EXTRACT(EPOCH FROM (endtime - starttime)/3600))) ::integer
        		FROM Booking B JOIN Car C on (regno = car)
        		WHERE madeBy = member_no_input
        		ORDER BY date DESC;
        	END
        $BODY$
          LANGUAGE plpgsql;
       

          -- Function: carsharing.get_all_cars()

          --DROP FUNCTION carsharing.get_all_cars();

          CREATE OR REPLACE FUNCTION carsharing.get_all_cars()
            RETURNS TABLE(car_regno regotype, car_name character varying, car_make character varying, car_model character varying, car_year integer, car_transmission character varying) AS
          $BODY$
          	BEGIN

          	RETURN QUERY
          		SELECT regno, name, make, model, year, transmission
          		FROM Car;
          	END
          $BODY$
            LANGUAGE plpgsql;
            -- Function: carsharing.get_bay(character varying)

            -- DROP FUNCTION carsharing.get_bay(character varying);

            CREATE OR REPLACE FUNCTION carsharing.get_bay(IN bay_name character varying)
              RETURNS TABLE(name_of_bay character varying, bay_description text, bay_address character varying, bay_gps_lat double precision, bay_gps_long double precision) AS
            $BODY$

            BEGIN
            	RETURN QUERY
            		SELECT name, description, address, gps_lat, gps_long
            		FROM CarBay
            		WHERE name = bay_name;
            END
            $BODY$
              LANGUAGE plpgsql;
             


              -- Function: carsharing.get_booking(character varying, character varying, character varying)

              -- DROP FUNCTION carsharing.get_booking(character varying, character varying, character varying);

              CREATE OR REPLACE FUNCTION carsharing.get_booking(
                  IN input_date character varying,
                  IN input_hour character varying,
                  IN input_car character varying)
                RETURNS TABLE(session_membername text, session_car_regno regotype, session_car_name character varying, session_date date, session_time time without time zone, session_duration text, session_when_booked timestamp without time zone, session_car_bay character varying) AS
              $BODY$

              DECLARE

              BEGIN
              	RETURN QUERY
              	SELECT M.nametitle || ' ' || M.namegiven || ' '|| M.namefamily, car, C.name, B.starttime ::DATE,
              	B.starttime ::TIME, (EXTRACT(HOUR FROM (B.endTime - B.startTime))) ||':00', B.whenbooked, CB.name
              	FROM Member M JOIN Booking B ON (madeBy = memberno) JOIN Car C ON (car = regno) JOIN Carbay CB ON (parkedAt = bayid)
              	WHERE DATE(B.starttime) = input_date ::DATE AND (EXTRACT(HOUR FROM (B.endTime - B.startTime))) ||':00' = input_hour AND c.regno = input_car;
              END
              $BODY$
                LANGUAGE plpgsql; 

                -- Function: carsharing.get_car_details(character)

                -- DROP FUNCTION carsharing.get_car_details(character);

                CREATE OR REPLACE FUNCTION carsharing.get_car_details(IN regnum character)
                  RETURNS TABLE(regno character varying, name character varying, make character varying, model character varying, yearmade integer, transmission character varying, category character varying, capacity integer, carbay integer, walkscore integer, mapurl character varying) AS
                $BODY$
                BEGIN
                RETURN QUERY
                SELECT C.regno, C.name, C.make, C.model, C.year, C.transmission, M.category, M.capacity, B.name, B.walkscore, B.mapurl
                FROM car C
                JOIN carmodel M
                ON C.model = M.model
                JOIN carbay B
                ON C.parkedat = B.bayid
                WHERE C.regno = regnum;
                END
                $BODY$
                  LANGUAGE plpgsql; 


                  -- Function: carsharing.get_cars_in_bay(character varying)

                  -- DROP FUNCTION carsharing.get_cars_in_bay(character varying);

                  CREATE OR REPLACE FUNCTION carsharing.get_cars_in_bay(IN bay_name_input character varying)
                    RETURNS TABLE(car_rego regotype, car_name character varying) AS
                  $BODY$

                  BEGIN
                  	RETURN QUERY
                  		SELECT C.regno, C.name
                  		FROM Car C JOIN CarBay CB ON (bayID = parkedAt)
                  		WHERE CB.name = bay_name_input;
                  END
                  $BODY$
                    LANGUAGE plpgsql; 


                    -- Function: carsharing.get_member_no(character varying)

                    -- DROP FUNCTION carsharing.get_member_no(character varying);

                    CREATE OR REPLACE FUNCTION carsharing.get_member_no(IN mememail character varying)
                      RETURNS TABLE(memberno integer) AS
                    $BODY$
                    BEGIN
                    SELECT memberno
                    FROM member M
                    WHERE M.email = mememail;
                    END
                    $BODY$
                      LANGUAGE plpgsql; 


                      -- Function: carsharing.get_num_cars_in_bay()

                      -- DROP FUNCTION carsharing.get_num_cars_in_bay();

                      CREATE OR REPLACE FUNCTION carsharing.get_num_cars_in_bay()
                        RETURNS TABLE(num_of_cars bigint) AS
                      $BODY$

                      BEGIN
                      	RETURN QUERY
                      		SELECT count(parkedAt)
                      		FROM  Car C JOIN CarBay CB ON (bayID = parkedAt)
                      		GROUP BY CB.name, CB.address
                      		ORDER BY CB.name, CB.address;
                      END
                      $BODY$
                        LANGUAGE plpgsql; 

                        -- Function: carsharing.get_salt(character varying, character varying)

                        -- DROP FUNCTION carsharing.get_salt(character varying, character varying);

                        CREATE OR REPLACE FUNCTION carsharing.get_salt(
                            IN input_email character varying,
                            IN dummy_variable character varying)
                          RETURNS TABLE(member_pw_salt text) AS
                        $BODY$
                        BEGIN
                        	RETURN QUERY
                        	SELECT pw_salt::text
                        	FROM member
                        	WHERE email = input_email;
                        END
                        $BODY$
                          LANGUAGE plpgsql; 


                          -- Function: carsharing.getallbookings(integer)

                          -- DROP FUNCTION carsharing.getallbookings(integer);

                          CREATE OR REPLACE FUNCTION carsharing.get_all_bookings(IN memberno integer)
                            RETURNS TABLE(regno text, name character varying, starttime timestamp without time zone, duration interval) AS
                          $BODY$
                          BEGIN
                          RETURN QUERY
                          SELECT C.regno::text, C.name, B.starttime, (B.endtime-B.starttime) AS duration
                          FROM car C
                          JOIN booking B
                          ON C.regno = B.car
                          WHERE B.madeby = memberno
                          ORDER BY B.starttime DESC;
                          END
                          $BODY$
                            LANGUAGE plpgsql; 


                            -- Function: carsharing.getallcars()

                            -- DROP FUNCTION carsharing.getallcars();

                            CREATE OR REPLACE FUNCTION carsharing.get_all_cars()
                              RETURNS TABLE(carregno text, carname character varying, carmake character varying, model character varying, caryear integer, transmission character varying) AS
                            $BODY$
                            BEGIN
                            RETURN QUERY
                            --insert query here
                            SELECT car.regno::text, car.name, car.make, car.model, car.year, car.transmission
                            FROM car;
                            END
                            $BODY$
                              LANGUAGE plpgsql; 

                              -- Function: carsharing.insert_into_reservation_table(character varying, timestamp without time zone, timestamp without time zone)

                              -- DROP FUNCTION carsharing.insert_into_reservation_table(character varying, timestamp without time zone, timestamp without time zone);

                              CREATE OR REPLACE FUNCTION carsharing.insert_into_reservation_table(
                                  arg1 character varying,
                                  arg2 timestamp without time zone,
                                  arg3 timestamp without time zone)
                                RETURNS void AS
                              $BODY$
                              BEGIN
                              	IF NOT EXISTS(SELECT 1 FROM Reservation WHERE arg1 = car AND start_time = arg2 AND end_time = arg3) THEN
                              		INSERT INTO Reservation VALUES(arg1 ::RegoType, arg2, arg3);
                              	END IF;
                              END;
                              $BODY$
                                LANGUAGE plpgsql; 

                                -- Function: carsharing.make_booking(character varying, character varying, character varying, character varying, character varying)

                                -- DROP FUNCTION carsharing.make_booking(character varying, character varying, character varying, character varying, character varying);

                                CREATE OR REPLACE FUNCTION carsharing.make_booking(
                                    input_email character varying,
                                    input_car_rego character varying,
                                    input_date character varying,
                                    input_hour character varying,
                                    input_duration character varying)
                                  RETURNS boolean AS
                                $BODY$
                                DECLARE
                                	session_memno integer;
                                	session_starttime TIMESTAMP;
                                	session_endtime TIMESTAMP;
                                	session_duration TEXT;
                                	member_booked_already BOOLEAN;
                                	session_booking_id INTEGER;

                                BEGIN
                                	session_memno = (SELECT memberno FROM member WHERE email = input_email);
                                	session_starttime = (SELECT(((input_date || ' '|| input_hour || ':00') ::TIMESTAMP)));
                                	session_duration = (SELECT input_duration || ' hours');
                                	session_endtime = (SELECT(session_starttime + session_duration ::interval));
                                	session_booking_id = (SELECT max(bookingid) + 1 FROM Booking);

                                	IF session_starttime < CURRENT_TIMESTAMP THEN
                                		RETURN FALSE;
                                	END IF;

                                	-- check if the current member already  has a booking which overlaps with the selected timeperiod
                                	IF EXISTS
                                		(SELECT 1 FROM Booking B WHERE madeby = session_memno
                                		AND (-- conflicting booking
                                		      -- either it commences in the requested timeperiod
                                		      (start_time < session_endtime AND start_time > session_starttime)
                                		      OR
                                		      -- or ends in the the requested timeperiod
                                		      (end_time > session_starttime AND end_time < session_endtime)
                                		      OR
                                		      (start_time = session_starttime AND end_time = session_endtime)
                                		))
                                	THEN
                                		RETURN FALSE; -- transaction will rollback
                                	END IF;

                                	-- check whether the car is already booked by another member
                                	IF EXISTS
                                		(SELECT 1 FROM Reservation
                                		 WHERE car = input_car_rego -- there is a booking for the current vehicle
                                		 AND (-- conflicting booking
                                		      -- either it commences in the requested timeperiod
                                		      (start_time < session_endtime AND start_time > session_starttime)
                                		      OR
                                		      -- or ends in the the requested timeperiod
                                		      (start_time > session_starttime AND end_time < session_endtime)
                                		      OR
                                		      (start_time = session_starttime AND end_time = session_endtime)
                                		)
                                	)
                                	THEN
                                		RETURN FALSE; -- transaction will rollback
                                	END IF;

                                	-- check whether date is in the past

                                	INSERT INTO Booking VALUES(session_booking_id, input_car_rego, session_memno, CURRENT_TIMESTAMP, session_starttime, session_endtime);

                                	UPDATE Member SET stat_nrofbookings = stat_nrofbookings + 1;

                                	RETURN TRUE;
                                END
                                $BODY$
                                  LANGUAGE plpgsql; 


                                  -- Function: carsharing.populate_reservation_table()

                                  -- DROP FUNCTION carsharing.populate_reservation_table();

                                  CREATE OR REPLACE FUNCTION carsharing.populate_reservation_table()
                                    RETURNS TABLE(car_output regotype, starttime_output timestamp without time zone, endtime_output timestamp without time zone) AS
                                  $BODY$
                                  	BEGIN
                                  		RETURN QUERY
                                  		SELECT car, starttime, endtime
                                  		FROM Booking;
                                  	END;
                                  $BODY$
                                    LANGUAGE plpgsql; 


                                    -- Function: carsharing.search_bays(character varying)

                                    -- DROP FUNCTION carsharing.search_bays(character varying);

                                    CREATE OR REPLACE FUNCTION carsharing.search_bays(IN search_term character varying)
                                      RETURNS TABLE(bay_name character varying, bay_address character varying, bay_gps_lat double precision, bay_gps_long double precision) AS
                                    $BODY$

                                    BEGIN
                                    	RETURN QUERY
                                    	SELECT CB.name,CB.address, CB.gps_lat, CB.gps_long
                                    	FROM CarBay CB
                                    	WHERE CB.name ~ search_term OR address ~ search_term;
                                    END
                                    $BODY$
                                      LANGUAGE plpgsql; 

                                      -- Function: carsharing.update_home_bay(character varying, character varying)

                                      -- DROP FUNCTION carsharing.update_home_bay(character varying, character varying);

                                      CREATE OR REPLACE FUNCTION carsharing.update_home_bay(
                                          inputemail character varying,
                                          bayname character varying)
                                        RETURNS boolean AS
                                      $BODY$
                                      DECLARE
                                      	input_bayID integer;

                                      BEGIN
                                      input_bayID = (SELECT bayid FROM CarBay CB WHERE name = bayname);
                                      UPDATE Carsharing.Member SET Homebay = input_bayID
                                      ;
                                      RETURN TRUE;
                                      END
                                      $BODY$
                                        LANGUAGE plpgsql; 