DROP TABLE Reservation;

CREATE TABLE Reservation (
car RegoType not null,
start_time TIMESTAMP not null,
end_time TIMESTAMP not null,

CONSTRAINT Reservation_PK PRIMARY KEY (car, start_time, end_time)
);

DROP FUNCTION IF EXISTS Booking_Reservation_Trigger() CASCADE;

CREATE FUNCTION Booking_Reservation_Trigger() RETURNS trigger AS
$$
   BEGIN
      SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
      IF carsharing.check_booking(start_time, end_time) IS FALSE
      THEN 
      INSERT INTO Reservation VALUES(NEW.car, NEW.starttime, NEW.endtime);
      RETURN NEW;
      -- TODO: Tell user booking period no longer available.
   END
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS Reservation_Trigger ON Booking;

CREATE TRIGGER Reservation_Trigger
       AFTER INSERT OR UPDATE ON Booking
       FOR EACH ROW
       EXECUTE PROCEDURE Booking_Reservation_Trigger();

CREATE INDEX reservation_cover_ind ON Reservation USING btree (start_time, end_time, car);
