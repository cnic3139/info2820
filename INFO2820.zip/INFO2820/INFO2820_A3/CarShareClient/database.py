#!/usr/bin/env python3

from modules import pg8000
import hashlib, uuid
import configparser


# Define some useful variables
ERROR_CODE = 55929

#####################################################
##	Database Connect
#####################################################

def database_connect():
	# Read the config file
	config = configparser.ConfigParser()
	config.read('config.ini')

	# Create a connection to the database
	connection = None
	try:
		connection = pg8000.connect(database=config['DATABASE']['user'],
			user=config['DATABASE']['user'],
			password=config['DATABASE']['password'],
			host=config['DATABASE']['host'])
	except pg8000.OperationalError as e:
		print("""Error, you haven't updated your config.ini or you have a bad
		connection, please try again. (Update your files first, then check
		internet connection)
		""")
		print(e)
	#return the connection to use
	return connection

#####################################################
##	Login
#####################################################


def hash_password(salt, password):
    """
    Helper for check login returns hashed password.
    Password hash format is 'salt'+':'+'password'
    """
    # check that parameters are strings
    if type(salt)!=str:
        raise Exception('salt was %s but  must be a string', type(salt))
    if type(password)!=str:
        raise Exception('password must be a string')

    # hash string and format must be same as in database
    encoding = 'utf-8'
    hashstring = salt+':'+password
    hashstring = hashstring.encode(encoding)
    digest = hashlib.sha256(hashstring).hexdigest()
    # hash the hash string
    return digest

def get_salt(email, curr):
    """
    Helper for check login Gets the salt assigned to a member
    """
    curr.execute(""" SELECT * FROM CarSharing.get_salt(%s) """, (email,))
    try:
        salt = curr.fetchone()[0]
    except TypeError:
        raise Exception("NoneType Error: can't get index 0 of of NoneType. Did you run preprocess.py before trying to get salt?")
    return salt

def check_login(email, password):
    """
    Takes a password, hashes it and checks if a combination
    of user/password exists.
    :success:
    """
    conn = database_connect()
    curr = conn.cursor()

    # hash the input password
    salt = get_salt(email, curr)
    digest = hash_password(salt, password)
    # select user where user and (hashed) password
    curr.execute(""" SELECT * FROM CarSharing.check_login(%s ::varchar, %s ::varchar); """, (email, digest))
    success = curr.fetchone()

    curr.close()
    conn.close()
    return success


#####################################################
##	Homebay
#####################################################
def update_homebay(email, bayname):
	conn = database_connect()
	curr = conn.cursor()
	try:
		curr.execute(""" SELECT * FROM CarSharing.update_home_bay(%s, %s) """, (email, bayname))
	except:
		#Transaction failed
		conn.rollback()
		return False
	#successful Transaction
	conn.commit()
	curr.close()
	conn.close()
	return True
#####################################################
##	Booking (make, get all, get details)
#####################################################

def populate_reservation_table():
	conn = database_connect()
	curr = conn.cursor()
	# todo: make lIMIT a fucntion of database size if production
	curr.execute(""" SELECT * FROM CarSharing.populate_reservation_table() ORDER BY whenbooked LIMIT 1000""")

	for values in curr.fetchall():
		curr.execute(""" SELECT * FROM CarSharing.insert_into_reservation_table(%s, %s, %s)""", (values[0], values[1], values[2]))


	conn.commit()

	curr.close()
	conn.close()
	return None

def make_booking(email, car_rego, date, hour, duration):

	conn = database_connect()
	curr = conn.cursor()


	curr.execute(""" SELECT * FROM CarSharing.make_booking(%s, %s, %s, %s, %s) """, (email, car_rego, date, hour, duration))

	val = curr.fetchone()

	if val[0] == False:
		#Transaction Failed
		conn.rollback()

	conn.commit()
	curr.close()
	conn.close()
	return val[0]

def get_all_bookings(email):

	conn = database_connect()
	curr = conn.cursor()

	curr.execute(""" SELECT * FROM CarSharing.get_all_booking(%s) """, (email,))

	val = []

	for row in curr.fetchall():
		val.append(row)

	curr.close()
	conn.close()
	return val

def get_booking(b_date, b_hour, car):
	conn = database_connect()
	curr = conn.cursor()

	#convert integer hour 'text'
	b_hour = b_hour + ':00'

	curr.execute(""" SELECT * FROM CarSharing.get_booking(%s, %s, %s) """, (b_date, b_hour, car))
	val = curr.fetchone()
	curr.close()
	conn.close()

	return val


#####################################################
##	Car (Details and List)
#####################################################

def get_car_details(regno):

	conn = database_connect()
	curr = conn.cursor()

	curr.execute("""SELECT * FROM CarSharing.get_car_details(%s)""", (regno,))

	val = curr.fetchone
	curr.close()
	conn.close()
	return val

def get_all_cars():

	conn = database_connect()
	curr = conn.cursor()
	curr.execute(""" SELECT * FROM CarSharing.get_all_cars() """)

	val = []

	for values in curr.fetchall():
		val.append(values)

	curr.close()
	conn.close()
	return val
#####################################################
##	Bay (detail, list, finding cars inside bay)
#####################################################

def get_all_bays():

	conn = database_connect()
	curr = conn.cursor()
	curr.execute(""" SELECT * FROM CarSharing.get_all_bays_and_count()""")

	val = []

	for values in curr.fetchall():
		val.append(values)

	curr.close()
	conn.close()
	return val

def get_bay(name):
	conn = database_connect()
	curr = conn.cursor()

	curr.execute(""" SELECT * FROM CarSharing.get_bay(%s) """ , (name, ))

	val = curr.fetchone()
	curr.close()
	conn.close()
	return val

def search_bays(search_term):

	conn = database_connect()
	curr = conn.cursor()
	dummy_variable = 'dummy'
	curr.execute("""SELECT * FROM CarSharing.search_bays(%s)""" , (search_term,))

	val = []

	for values in curr.fetchall():
		val.append(values)

	curr.close()
	conn.close()
	return val

def get_cars_in_bay(bay_name):

	conn = database_connect()
	curr = conn.cursor()
	bay_name = str(bay_name)
	print (bay_name)
	curr.execute("""SELECT * FROM CarSharing.get_cars_in_bay(%s)""" , (bay_name,))

	val = []

	for values in curr.fetchall():
		val.append(values)
	curr.close()
	conn.close()
	return val
