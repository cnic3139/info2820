"""
Run this after loading sample data to add salt and hash password.
Not for production.
"""

#!/usr/bin/env python3

from modules import pg8000
import hashlib, uuid
import configparser

# Define some useful variables
ERROR_CODE = 55929

#####################################################
##  Database Connect
#####################################################

def database_connect():
    # Read the config file
    config = configparser.ConfigParser()
    config.read('config.ini')

    # Create a connection to the database
    connection = None
    try:
        connection = pg8000.connect(database=config['DATABASE']['user'],
            user=config['DATABASE']['user'],
            password=config['DATABASE']['password'],
            host=config['DATABASE']['host'])
    except pg8000.OperationalError as e:
        print("""Error, you haven't updated your config.ini or you have a bad
        connection, please try again. (Update your files first, then check
        internet connection)
        """)
        print(e)
    #return the connection to use
    return connection

def set_salt(email, curr):
    pysalt = uuid.uuid4().hex
    salted = curr.execute(""" SELECT carsharing.set_salt(%s,%s) """, (email, pysalt))

def hash_password(email, curr):

    # get the salt and password
    curr.execute(""" SELECT pw_salt from member where email=%s""",(email,))
    salt = curr.fetchone()[0]
    curr.execute(""" SELECT password from member where email=%s """,(email,))
    password = curr.fetchone()[0]

    # hash the password and update the record
    encoding = 'utf-8'
    hashstring = (salt+':'+password).encode(encoding)
    digest = hashlib.sha256(hashstring).hexdigest()
    hashed = curr.execute(""" SELECT carsharing.hash_password(%s, %s) """, (email, digest))

def populate_reservation_table():
	conn = database_connect()
	curr = conn.cursor()
	# todo: make lIMIT a fucntion of database size if production
	curr.execute(""" SELECT * FROM CarSharing.populate_reservation_table() ORDER BY starttime_output LIMIT 1000""")

	for values in curr.fetchall():
		curr.execute(""" SELECT * FROM CarSharing.insert_into_reservation_table(%s, %s, %s)""", (values[0], values[1], values[2]))


	conn.commit()

	curr.close()
	conn.close()
	return None

def main():
    """
    Calls functions which set salt for each member
    and update each member password with a salted hash
    """

    # Get every member
    conn = database_connect()
    curr = conn.cursor()
    curr.execute(""" SELECT * from member """)
    members = curr.fetchall()

    for entry in members:
        email = entry[1]
        set_salt(email, curr)
        hash_password(email, curr)
    conn.commit()
    conn.close()
    print("salted and hashed passwords")

    """
    Create a table of the most frequent reservations based on sample data.
    """
    populate_reservation_table()

    return 0



main()
