﻿-- Function: carsharing.get_member_salt(character varying, character varying)

-- DROP FUNCTION carsharing.get_member_salt(character varying, character varying);

CREATE OR REPLACE FUNCTION carsharing.get_member_salt(
    IN inputemail character varying)
  RETURNS TABLE(member_pw_salt text) AS
$BODY$

BEGIN
	RETURN QUERY
	SELECT pw_salt::text
	FROM Member
	WHERE email = inputemail;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
  ROWS 1000;
ALTER FUNCTION carsharing.get_member_salt(character varying)
  OWNER TO char5770;
