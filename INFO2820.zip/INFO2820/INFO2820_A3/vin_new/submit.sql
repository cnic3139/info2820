CREATE OR REPLACE FUNCTION CarSharing.get_all_bays_and_count() RETURNS TABLE
(
bay_name VARCHAR,
bay_address VARCHAR,
count BIGINT
) AS $$

BEGIN 
	RETURN QUERY
		SELECT CB.name, CB.address, count(parkedAt)
		FROM Car C JOIN CarBay CB ON (bayID = parkedAt)
		GROUP BY CB.name, CB.address
		ORDER BY CB.name, CB.address;

END
$$ LANGUAGE plpgsql;

DROP FUNCTION CarSharing.checkLogin(character varying, character varying);

CREATE OR REPLACE FUNCTION CarSharing.checkLogin(IN inputemail VARCHAR(50), IN input_hash VARCHAR(600)) RETURNS TABLE
(
nickname varchar,
nametitle varchar,
namegiven varchar,
namefamily varchar,
address varchar,
name varchar,
since date,
subscribed varchar,
stat_nrOfBookings integer
) AS
$$

BEGIN
	RETURN QUERY
	SELECT M.nickname, M.nametitle, M.namegiven, M.namefamily, M.address, C.name, M.since, M.subscribed, M.stat_nrOfBookings
		FROM CarSharing.Member M
		JOIN CarSharing.carbay C ON (homebay = bayid)
		WHERE EXISTS(SELECT 1 FROM CarSharing.Member M2 WHERE M2.email = inputemail AND M2.password_hash = input_hash)
		AND (M.email = inputemail);
END
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION CarSharing.get_cars_in_bay(IN bay_name_input VARCHAR(80), IN dummy_variable varchar) RETURNS TABLE
(
car_rego RegoType,
car_name VARCHAR
) AS $$

BEGIN
	RETURN QUERY
		SELECT C.regno, C.name
		FROM Car C JOIN CarBay CB ON (bayID = parkedAt)
		WHERE CB.name = bay_name_input;
END
$$ LANGUAGE plpgsql;

DROP FUNCTION get_bay(character varying);

CREATE OR REPLACE FUNCTION CarSharing.get_bay(bay_name VARCHAR(80), IN dummy_variable varchar) RETURNS TABLE
(
name_of_bay VARCHAR,
bay_description TEXT,
bay_address VARCHAR,
bay_gps_lat FLOAT,
bay_gps_long FLOAT
) AS $$

BEGIN
	RETURN QUERY
		SELECT name, description, address, gps_lat, gps_long
		FROM CarBay
		WHERE name = bay_name;
END
$$ LANGUAGE plpgsql;

DROP FUNCTION CarSharing.search_bays(character varying);

CREATE OR REPLACE FUNCTION CarSharing.search_bays(IN search_term VARCHAR, IN dummy_variable varchar) RETURNS TABLE
(
bay_name VARCHAR,
bay_address VARCHAR,
bay_gps_lat FLOAT,
bay_gps_long FLOAT
) AS
$$

BEGIN
	RETURN QUERY
	SELECT CB.name,CB.address, CB.gps_lat, CB.gps_long
	FROM CarBay CB
	WHERE CB.name ~ search_term OR address ~ search_term;
END
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CarSharing.get_member_salt(IN inputemail VARCHAR(50), IN dummy_variable VARCHAR) RETURNS TABLE
(
member_pw_salt CHAR
) AS
$$

BEGIN
	RETURN QUERY
	SELECT pw_salt
	FROM Member
	WHERE email = inputemail;
END
$$ LANGUAGE plpgsql;
