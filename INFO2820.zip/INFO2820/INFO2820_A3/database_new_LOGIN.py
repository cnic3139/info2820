#!/usr/bin/env python3

from modules import pg8000
import hashlib, uuid
import configparser
import bcrypt

# Define some useful variables
ERROR_CODE = 55929

#####################################################
##  Database Connect
#####################################################

def database_connect():
    # Read the config file
    config = configparser.ConfigParser()
    config.read('config.ini')

    # Create a connection to the database
    connection = None
    try:
        connection = pg8000.connect(database=config['DATABASE']['user'],
            user=config['DATABASE']['user'],
            password=config['DATABASE']['password'],
            host=config['DATABASE']['host'])
    except pg8000.OperationalError as e:
        print("""Error, you haven't updated your config.ini or you have a bad
        connection, please try again. (Update your files first, then check
        internet connection)
        """)
        print(e)
    #return the connection to use
    return connection

#####################################################
##  Login
#####################################################

def hash_password(salt, password):
    """ 
    Helper for check login returns hashed password.
    Password hash format is 'salt'+':'+'password'
    """
    # check that parameters are strings
    if type(salt)!=str:
        raise Exception('salt was %s but  must be a string', type(salt))
    if type(password)!=str:
        raise Exception('password must be a string')
    
    # hash string and format must be same as in database
    encoding = 'utf-8'
    hashstring = salt+':'+password
    hashstring = hashstring.encode(encoding)
    digest = hashlib.sha256(hashstring).hexdigest() 
    # hash the hash string
    return digest

def get_salt(email, curr):
    """
    Helper for check login Gets the salt assigned to a member
    """
    curr.execute(""" SELECT CarSharing.get_member_salt(%s) """, (email,))
    salt = curr.fetchone()[0]
    return salt

def check_login(email, password):
    """
    Takes a password, hashes it and checks if a combination 
    of user/password exists.
    :success: 
    """
    conn = database_connect()
    curr = conn.cursor()
     
    # hash the input password
    salt = get_salt(email, curr)
    digest = hash_password(salt, password)
    print("salt: ", salt) 
    # select user where user and (hashed) password
    curr.execute(""" SELECT * FROM CarSharing.check_login(%s ::varchar, %s ::varchar); """, (email, digest))
    success = curr.fetchone()
    
    curr.close()
    conn.close()
    return success


#####################################################
##  Homebay
#####################################################
def update_homebay(myemail, bay):
    conn = database_connect()
    curr = conn.cursor()
    #INSERT TRANSACTION HERE
    curr.execute(""" UPDATE CarSharing.member SET homebay = %s WHERE email = %s""", (bay, myemail))
    conn.close()
    return True

#####################################################
##  Booking (make, get all, get details)
#####################################################

def make_booking(email, car_rego, date, hour, duration):
    # TODO
    # Insert a new booking
    # Make sure to check for:
    #       - If the member already has booked at that time
    #       - If there is another booking that overlaps
    #       - Etc.
    # return False if booking was unsuccessful :)
    # We want to make sure we check this thoroughly

    conn = database_connect()
    curr = conn.cursor()

    try:
        # stored procedure to check if car exists or is booked.
        ## need transaction

        curr.execute("INSERT INTO Booking VALUES(car_regno, memberno, date(hour+date), date(hour+date)+duration)")

    except:
        print ("something went wrong")


    return True

def helper_get_member_no(param_email, curr):
    return curr.execute("SELECT * FROM member WHERE email = %s """, (param_email,))
    
def get_all_bookings(email):
    #val = [['66XY99', 'Ice the Cube', '01-05-2016', '10', '4', '29-04-2016'],['66XY99', 'Ice the Cube', '27-04-2016', '16'], ['WR3KD', 'Bob the SmartCar', '01-04-2016', '6']]

    conn = database_connect()
    curr = conn.cursor()

    # todo as stored proc
    member_number = helper_get_member_no(email, curr)
    curr.execute("""SELECT * FROM booking WHERE madeBy = %s """, (member_number,))

    result = []

    for row in curr.fetchall():
        result.append(row)
    return result
    

def get_booking(b_date, b_hour, car):
    conn = database_connect()
    curr = conn.cursor()

    # check if this works
    start_time = str(b_hour + b_date)

    curr.execute("SELECT M.nickname, B.car \
    FROM booking B JOIN member M ON (madeBy = memberno) JOIN Car ON (car = regno)\
    WHERE B.startTime = start_time AND B.car = car")
    
    val = curr.fetchone
    # TODO
    # Get the information about a certain booking
    # It has to have the combination of date, hour and car

    return val


#####################################################
##  Car (Details and List)
#####################################################

def get_car_details(regno):
    #val = ['66XY99', 'Ice the Cube','Nissan', 'Cube', '2007', 'auto', 'Luxury', '5', 'SIT', '8', 'http://example.com']
    conn = database_connect()
    curr = conn.cursor()
    # TODO, work out what numbers mean, probs number of bookings and number of cars parked?
    curr.execute("SELECT C.regno, C.name, C.make, C.model, C.year, C.transmission, C.parkedAt, CB.name \
    FROM booking B JOIN car C ON (car = regno) JOIN Carbay CB ON (parkedAt = bayid)\
    WHERE C.regno = regno")
    
    val = curr.fetchone

    return val

def get_all_cars():
    #val = [ ['66XY99', 'Ice the Cube', 'Nissan', 'Cube', '2007', 'auto'], ['WR3KD', 'Bob the SmartCar', 'Smart', 'Fortwo', '2015', 'auto']]

    conn = database_connect()
    curr = conn.cursor()
    curr.execute("SELECT regno, name, make, model, year, transmission \
    FROM Car")
    i = 0
    
    val = []

    for values in curr.fetchall():
        val.append(values)

    # TODO
    # Get all cars that PeerCar has
    # Return the results

    return val
#####################################################
##  Bay (detail, list, finding cars inside bay)
#####################################################

def get_all_bays():
    #val = [['SIT', '123 Some Street, Boulevard', '2'], ['some_bay', '1 Somewhere Road, Right here', '1']]
    conn = database_connect()
    curr = conn.cursor()
    curr.execute(""" SELECT * FROM CarSharing.get_all_bays_and_count()""")

    val = []

    for values in curr.fetchall():
        val.append(values)

    # TODO
    # Get all the bays that PeerCar has :)
    # And the number of cars
    # Return the results
    curr.close()
    conn.close()
    return val

def get_bay(name):
    #val = ['SIT', 'Home to many (happy?) people.', '123 Some Street, Boulevard', '-33.887946', '151.192958']   
    conn = database_connect()
    curr = conn.cursor()

    curr.execute(""" SELECT * FROM CarSharing.get_bay(%s) """ , (name, ))

    val = curr.fetchone()
 
    return val

    # TODO
    # Get the information about the bay with this unique name
    # Make sure you're checking ordering ;)

def search_bays(search_term):
    #val = [['SIT', '123 Some Street, Boulevard', '-33.887946', '151.192958']]

    conn = database_connect()
    curr = conn.cursor()
    dummy_variable = 'dummy'
    curr.execute("""SELECT * FROM CarSharing.search_bays_and_num_cars(%s, %s)""" , (search_term, 'dummy variable'))

    val = []

    for values in curr.fetchall():
        val.append(values)

    return val

    # TODO
    # Select the bays that match (or are similar) to the search term
    # You may like this

def get_cars_in_bay(bay_name):
    #val = [ ['66XY99', 'Ice the Cube'], ['WR3KD', 'Bob the SmartCar']]
    conn = database_connect()
    curr = conn.cursor()
    bay_name = str(bay_name)
    print (bay_name)
    curr.execute("""SELECT * FROM CarSharing.get_cars_in_bay(%s, %s)""" , (bay_name, 'dummy variable'))

    val = []

    for values in curr.fetchall():
        val.append(values)
    
    return val
